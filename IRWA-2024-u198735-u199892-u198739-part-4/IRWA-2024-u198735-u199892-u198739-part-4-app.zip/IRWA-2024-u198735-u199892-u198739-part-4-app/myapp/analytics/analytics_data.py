import json
import random


class AnalyticsData:
    """
    An in memory persistence object.
    Declare more variables to hold analytics tables.
    """
    # statistics table 1
    # fact_clicks is a dictionary with the click counters: key = doc id | value = click counter
    fact_clicks = dict([])

    # statistics table 2
    fact_http_requests = dict([])

    # statistics table 3
    fact_search_options = dict([])

    # statistics table 4
    fact_http_sessions = dict([])

    # statistics table 5 
    # fact_queries is a dictionary with the queries counters: key = query | value = query counter
    fact_queries = dict([])

    # key = query | value = list of document ids
    fact_queries_to_docs = dict([])

    #clicks start being -1 because when return to the main page you add 1 click, and we do not want to add when we first enter
    fact_tot_num_clicks = -1
    fact_browser = 0
    fact_os = 0



    def save_query_terms(self, terms: str) -> int:
        print(self)
        return random.randint(0, 100000)


class ClickedDoc:
    def __init__(self, doc_id, description, counter):
        self.doc_id = doc_id
        self.description = description
        self.counter = counter

    def to_json(self):
        return self.__dict__

    def __str__(self):
        """
        Print the object content as a JSON string
        """
        return json.dumps(self)
