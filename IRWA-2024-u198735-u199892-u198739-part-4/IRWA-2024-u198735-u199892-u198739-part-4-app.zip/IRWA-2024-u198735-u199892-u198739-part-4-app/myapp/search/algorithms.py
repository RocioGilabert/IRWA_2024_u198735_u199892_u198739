import re
from nltk.stem import PorterStemmer
from nltk.corpus import stopwords
from collections import defaultdict
import numpy as np

def build_terms(line):
    stemmer = PorterStemmer()
    stop_words = set(stopwords.words("english"))

    ## Transform into lowercase
    line=  line.lower()
    #Remove urls
    line = re.sub(r'http[s]?://\S+', '', line)
    #remove apostrophes
    line = re.sub(r"'s\b", '', line)
    #Remove punctuations marks
    line = re.sub(r'[!"$%&()*+,-./:;<=>?[\]^_`{|}~#]', ' ', line)
    #Remove emojis, symbols, pictograms...
    line = re.sub(r"["
        "\U0001F600-\U0001F64F"
        "\U0001F300-\U0001F5FF"
        "\U0001F680-\U0001F6FF"
        "\U0001F1E0-\U0001F1FF"
        "\U00002702-\U000027B0"
        "\U000024C2-\U0001F251"
        "]+", ' ', line)
    #Tokenize the text
    line =  line.split()
    #Remove stop-words
    line=[x for x in line if x not in stop_words]
    #Perform stemming
    line=[stemmer.stem(x) for x in line]

    return line


def extract_hashtags(content):
    # Find all words that begin with # symbol
    hashtags = re.findall(r'#\w+', content)
    return hashtags


#Function to have the tokens that correspond to each tweet
def get_token_tweets(dic):
  token_tweets = {}
  for doc_id in dic:
    token_tweets[doc_id] = dic[doc_id].processed_tweet
  return token_tweets


def create_index(dic, clean_tweets):
  index = {}

  for doc_id in dic: #for each document
    tokens = clean_tweets[doc_id] #we take the tokens
    

    # we iterate through the document tokens
    for token in tokens:
        if token in index: #if the token has already appeared, add the document
            index[token].append(doc_id)
        else: #add a new entry for the token
            index[token] = [doc_id]

  return index


def basic_search(query, index):
  query = build_terms(query)
  # we initialize tweets with the documents were the first query term appears
  if query[0] in index:
    tweets = set(index[query[0]])
  else:
    return []  # if the first term has no matching documents, return an empty list
  for word in query[1:]: #for each subsequent term
    try:
      term_tweet = index[word] #find its documents
      tweets = tweets & set(term_tweet) #compute an AND to know the documents were all terms appear
    except:
      pass
  tweets = list(tweets)
  return tweets


def tfidf_cosine(query, inverted_index, total_tweets, clean_tweets):
  terms = build_terms(query)
  tweets_scores = defaultdict(float) #dictionary to store doc_id -> score
  doc_vectors = defaultdict(lambda: defaultdict(float))  # Vectors for each document TF-IDF values
  query_vector = defaultdict(float)
  common_docs = basic_search(query, inverted_index) #we find the list of common documents for all the words of the query

  for term in terms: #for each word of the query
    if term in inverted_index:
      df = len(inverted_index[term]) # we compute df: the number of documents containing the term
      idf = np.round(np.log(total_tweets/df), 4) #we compute IDF with the formula
      term_frequency = terms.count(term)  # term frequency of the term in the QUERY
      tf = np.round(term_frequency / len(terms), 4)  # tf for the query term as term_frequency/words in the query
      query_vector[term] = tf * idf #we add it to the query vector

      for doc_id in common_docs: #for each document that conatins the query
        term_frequency = clean_tweets[doc_id].count(term)   #term frequency of the term in the document
        tf = np.round(term_frequency / len(clean_tweets[doc_id]), 4) #we compute the tf term_frequency/words in that document
        doc_vectors[doc_id][term] = tf * idf #we add it to the document vector

  for doc_id, doc_vector in doc_vectors.items():
    # Dot product between query vector and document
    tweets_scores[doc_id] = sum(query_vector[term] * doc_vector.get(term, 0) for term in query_vector) #if term not in doc_vector it returns 0

  #we order the tweet scores in descending order by score
  ranked_tweets = dict(sorted(tweets_scores.items(), key=lambda x: x[1], reverse=True))

  return ranked_tweets


def min_max_scaling(tweets, doc_id, common_docs, value):
    min_value = min(getattr(tweets[doc_id], value) for id in common_docs)
    max_value = max(getattr(tweets[doc_id], value) for id in common_docs)
    if max_value == min_value:
       return 0.0  # Devuelve un valor constante arbitrario
    return (getattr(tweets[doc_id], value) - min_value) / (max_value - min_value)

def ourscore_cosine(query, inverted_index, total_tweets, clean_tweets, corpus):
    terms = build_terms(query)
    tweets_scores = defaultdict(float) #dictionary to store doc_id -> score
    doc_vectors = defaultdict(lambda: defaultdict(float))  # Vectors for each document TF-IDF values
    query_vector = defaultdict(float)
    common_docs = basic_search(query, inverted_index) #we find the list of common documents for all the words of the query
    for term in terms: #for each word
        if term in inverted_index:
            df = len(inverted_index[term]) # we compute document frequency (DF) that is the number of documents containing the term
            idf = np.round(np.log(total_tweets/df), 4) #we compute IDF with the formula
            term_frequency = terms.count(term)  # Term frequency of the term in the query
            tf = np.round(term_frequency / len(terms), 4)  # TF for query term
            query_vector[term] = tf * idf #we add it to the query vector

            for doc_id in common_docs: #for each document that conatins the query
                term_frequency = clean_tweets[doc_id].count(term)   #term frequency of the term in the document
                tf = np.round(term_frequency / len(clean_tweets[doc_id]), 4) #we compute the tf term_frequency/words in that document
                doc_vectors[doc_id][term] = tf * idf
    for doc_id, doc_vector in doc_vectors.items():
    # Dot product between query vector and document vector
        dot_product = sum(query_vector[term] * doc_vector.get(term, 0) for term in query_vector) #if term not in doc_vector it returns 0

        num_likes = min_max_scaling(corpus, doc_id, common_docs, 'likes')
        num_retweets = min_max_scaling(corpus, doc_id, common_docs, 'retweets')
        is_verified = corpus[doc_id].verified
        num_followers = min_max_scaling(corpus, doc_id, common_docs, 'followers')
     
        if is_verified:
            tweets_scores[doc_id] = 0.6 * dot_product + 0.4 *(num_likes*0.4 + num_retweets*0.6 - num_followers * 0.3)
        else:
            tweets_scores[doc_id] = 0.6 * dot_product + 0.4 * (num_likes*0.4 + num_retweets*0.6 + num_followers * 0.3)


  #we order the tweet scores in descending order by score
    ranked_tweets = dict(sorted(tweets_scores.items(), key=lambda x: x[1], reverse=True))
    return ranked_tweets


def bm25(query, inverted_index, total_tweets, clean_tweets):
  terms = build_terms(query)
  RSV = defaultdict(float) #dictionary to store doc_id -> score
  k1 = 1.2
  b = 0.75
  avg_doc_length = np.mean([len(doc) for doc in clean_tweets.values()])
  common_docs = basic_search(query, inverted_index) #we find the list of common documents for all the words of the query

  for term in terms: #for each word
    if term in inverted_index:
      df = len(inverted_index[term]) # we compute document frequency (DF) that is the number of documents containing the term
      idf = np.round(np.log(total_tweets/df), 4) #we compute IDF with the formula

      for doc_id in common_docs: #for each document that contains all the terms in the query
        term_frequency = clean_tweets[doc_id].count(term)   #term frequency of the term in the document
        tf = np.round(term_frequency / len(clean_tweets[doc_id]), 4) #we compute the tf term_frequency/words in that document
        # we compute tf-idf and add it to the tweet score
        RSV[doc_id] += idf * (k1 +1)*tf/(tf+k1*(1-b+b*len(clean_tweets[doc_id])/avg_doc_length))

  #we order the tweet scores in descending order by score
  ranked_tweets = dict(sorted(RSV.items(), key=lambda x: x[1], reverse=True))

  return ranked_tweets

def calculate_tweet_vector(model, tweet):
  tweet_vector = []
  for word in tweet:
    if word in model.wv:
        tweet_vector.append(model.wv[word])
    else:
        tweet_vector.append(np.zeros(model.vector_size))
  return np.mean(tweet_vector, axis=0)

def word2vec_cosine(query, model, inverted_index, tokens):
    ranked_docs = tfidf_cosine(query, inverted_index, len(tokens), tokens) #retrieve the relevant documents

    tweet_vectors = {}
    for doc_id in list(ranked_docs.items()): #for each document retrieved
        for tweet in tokens:
            if doc_id[0] == tweet:
                tweet_vectors[doc_id[0]] = calculate_tweet_vector(model, tokens[doc_id[0]])

    query_vector = calculate_tweet_vector(model, build_terms(query))

    #Cosine similarity
    similarity_scores = {}
    for doc_id, tweet_vector in tweet_vectors.items():
      similarity_scores[doc_id] = np.dot(tweet_vector, query_vector.T)

    top_20_tweets = dict(sorted(similarity_scores.items(), key=lambda x: x[1], reverse=True))
    return top_20_tweets

def search_in_corpus(query):
    # 1. create create_tfidf_index

    # 2. apply ranking
    return ""
