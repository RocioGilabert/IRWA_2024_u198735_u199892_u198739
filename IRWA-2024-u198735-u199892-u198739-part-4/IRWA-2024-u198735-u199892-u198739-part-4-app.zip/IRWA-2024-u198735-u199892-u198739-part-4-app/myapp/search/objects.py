import json


class Document:
    """
    Original corpus data as an object
    """

    def __init__(self, id, title, description, processed_tweet, doc_date, likes, retweets, url,username, hashtags, verified, followers):
        self.id = id
        self.title = title
        self.description = description
        self.processed_tweet = processed_tweet
        self.doc_date = doc_date
        self.likes = likes
        self.retweets = retweets
        self.url = url
        self.username = username
        self.hashtags = hashtags
        self.verified = verified
        self.followers = followers


    def to_json(self):
        return self.__dict__

    def __str__(self):
        """
        Print the object content as a JSON string
        """
        return json.dumps(self)


class StatsDocument:
    """
    Original corpus data as an object
    """

    def __init__(self, id, title, description, doc_date, url, count):
        self.id = id
        self.title = title
        self.description = description
        self.doc_date = doc_date
        self.url = url
        self.count = count

    def __str__(self):
        """
        Print the object content as a JSON string
        """
        return json.dumps(self)


class ResultItem:
    def __init__(self, id, title, description, doc_date, url, ranking, likes, username):
        self.id = id
        self.title = title
        self.description = description
        self.doc_date = doc_date
        self.url = url
        self.ranking = ranking
        self.likes = likes
        self.username = username

class UserReq:
    def __init__(self, id, count):
        self.id = id
        self.count = count

class Session:
    def __init__(self, id, start, actual_time, clicks, browser, os):  
        self.id = id
        self.start = start.replace(microsecond=0)
        self.actual_time = actual_time
        start_time = start.hour * 60 + start.minute
        end_time = actual_time.hour * 60 + actual_time.minute
        self.time_elapsed = end_time-start_time
        self.clicks = clicks
        self.browser = browser
        self.os= os

class Query:
    def __init__(self, query, count):
        self.query = query
        self.count = count 

    def to_json(self):
        return self.__dict__
