import pandas as pd
import json
from myapp.core.utils import load_json_file
from myapp.search.objects import Document
from myapp.search.algorithms import *
import re
import pickle


_corpus = {}


def load_corpus(file_name) -> [Document]:
    """
    Load file and transform to dictionary with each document as an object for easier treatment when needed for displaying
     in results, stats, etc.
    :param path:
    :return:
    """
    df = _load_corpus_as_dataframe(file_name)
    df.apply(_row_to_doc_dict, axis=1)
    return _corpus


def _load_corpus_as_dataframe(file_name):
    """
    Load documents corpus from file in 'path'
    :return:
    """
    with open(file_name, "r") as file: # We open the json file and save it 
        json_data = [json.loads(line) for line in file]
    tweets_df = _load_tweets_as_dataframe(json_data)
    return tweets_df


def _load_tweets_as_dataframe(json_data):
    data = pd.DataFrame(json_data) # We save it as a dataframe
    return data
    

def load_tweets_as_dataframe2(json_data):
    """Load json into a dataframe

    Parameters:
    path (string): the file path

    Returns:
    DataFrame: a Panda DataFrame containing the tweet content in columns
    """
    # Load the JSON as a Dictionary
    tweets_dictionary = json_data.items()
    # Load the Dictionary into a DataFrame.
    dataframe = pd.DataFrame(tweets_dictionary)
    # remove first column that just has indices as strings: '0', '1', etc.
    dataframe.drop(dataframe.columns[0], axis=1, inplace=True)
    return dataframe


def load_tweets_as_dataframe3(json_data):
    """Load json data into a dataframe

    Parameters:
    json_data (string): the json object

    Returns:
    DataFrame: a Panda DataFrame containing the tweet content in columns
    """

    # Load the JSON object into a DataFrame.
    dataframe = pd.DataFrame(json_data).transpose()

    # select only interesting columns
    filter_columns = ["id", "full_text", "created_at", "entities", "retweet_count", "favorite_count", "lang"]
    dataframe = dataframe[filter_columns]
    return dataframe


def _row_to_doc_dict(row: pd.Series):
    # Corpus is a dictionary tweet id -> Document structure for each tweet
    _corpus[row['id']] = Document(row['id'], row['content'][0:100], row['content'],build_terms(row['content']), row['date'], 
    row['likeCount'], row['retweetCount'], row['url'], '@'+row['user']['username'], extract_hashtags(row['content']), 
    row['user']['verified'], row['user']['followersCount'])


