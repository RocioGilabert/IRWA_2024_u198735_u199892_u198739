import random

from myapp.search.objects import ResultItem, Document
from myapp.search.algorithms import *
from gensim.models import Word2Vec


def build_demo_results(corpus: dict, search_id, doc_scores):
    """
    Helper method, just to demo the app
    :return: a list of demo docs sorted by ranking
    """
    res = []
    for doc_id, rank in doc_scores.items(): 
        known_item = corpus.get(doc_id) # We get the information for the specific doc_id
        if known_item:
            # We save the information needed in ResultItem form
            res.append(ResultItem(known_item.id, known_item.title, known_item.description, known_item.doc_date, known_item.url, rank, 
                                  known_item.likes, known_item.username))

    return res


class SearchEngine:
    """educational search engine"""

    def search(self, search_query, search_id, corpus, selected_option):
        print("Search query:", search_query)

        results = []
        clean_tweets = get_token_tweets(corpus) # dictionary with id -> tokens
        index = create_index(corpus, clean_tweets) # inverted index

        # For each search option, we use its respective function and save it to doc_scores wich is a dictionary
        # with the form id -> score
        if selected_option == "TF-IDF Search":
            doc_scores = tfidf_cosine(search_query, index, len(clean_tweets), clean_tweets)
        
        elif selected_option == "Own Search Method":
            doc_scores = ourscore_cosine(search_query, index, len(clean_tweets), clean_tweets, corpus)

        elif selected_option == 'BM25':
            doc_scores = bm25(search_query, index, len(clean_tweets), clean_tweets)

        elif selected_option == 'Word2Vec':
            model = Word2Vec(list(clean_tweets.values()), vector_size=50, window=5, min_count=1)
            doc_scores = word2vec_cosine(search_query, model, index, clean_tweets)

        results = build_demo_results(corpus, search_id, doc_scores)  

        return results
